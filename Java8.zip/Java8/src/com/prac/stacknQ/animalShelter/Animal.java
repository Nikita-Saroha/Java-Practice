package com.prac.stacknQ.animalShelter;

public class Animal {
	
	public void makeSound(){};

}
