package com.prac.stacknQ.animalShelter;

public class Cat extends Animal {

	@Override
	public void makeSound() {
		// TODO Auto-generated method stub
		System.out.println("Meow!");
	}

}
