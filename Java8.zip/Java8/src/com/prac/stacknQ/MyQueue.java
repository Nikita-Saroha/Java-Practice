package com.prac.stacknQ;

public class MyQueue {
	
	

}
