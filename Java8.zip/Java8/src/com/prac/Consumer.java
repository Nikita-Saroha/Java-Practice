package com.prac;

public class Consumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
